﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Reflection;
using System.Drawing;
using System.Windows.Media.Imaging;

using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using Autodesk.Revit.Attributes;
using Autodesk.Revit.ApplicationServices;
using System.Diagnostics;

namespace RevitFamilyFileProcessing
{
    [Transaction(TransactionMode.Manual)]
    public class Apps : IExternalApplication
    {
        public Result OnShutdown(UIControlledApplication application)
        {
            TaskDialog.Show("Information", "Revit is closing");
            return Result.Succeeded;
        }

        public Result OnStartup(UIControlledApplication application)
        {
            string TabName = "Ex_DTI";
            string PanelName = "Digital Tool Installation";
            string addinpath = Assembly.GetExecutingAssembly().Location;
            string addinDirPath = Path.GetDirectoryName(addinpath);
            string iconpath = @"Resources\Importcsv.ico";
            string iconcompletepath = Path.Combine(addinDirPath, iconpath);
            application.CreateRibbonTab(TabName);
            RibbonPanel panel = application.CreateRibbonPanel(TabName, PanelName);
            PushButtonData PushButtonData = new PushButtonData("MetaDATA","Import Metadata", addinpath, "RevitFamilyFileProcessing.FamilyFileProcessor");
            PushButton pushbutton = panel.AddItem(PushButtonData) as PushButton;
            pushbutton.LargeImage = new BitmapImage(new Uri(iconcompletepath));
            pushbutton.ToolTip = "Import Metadata to Folder of Familes";

            string log1 = @"C:\Users\vmaruthappan\Desktop\Import Lookup Table\RevitFamilyFileProcessing\Nested Family\bin\Debug\Nested Family.dll";

            string log2 = @"C:\Users\vmaruthappan\Desktop\Ex_Ti_Missing Line Numbers_Updated\Ex_Ti_Missing Line Numbers\Ex_Ti_Missing Line Numbers\bin\Debug\Ex_Ti_Missing Line Numbers.dll";

            //string PanelName1 = "Nested Family";
            //string addinpath1 = Assembly.GetExecutingAssembly().Location;
            string addinDirPath1 = Path.GetDirectoryName(log1);
            string iconpath1 = @"Resources\NestedFamily.ico";
            string iconcompletepath1 = Path.Combine(addinDirPath, iconpath1);
            //application.CreateRibbonTab(TabName);
            //RibbonPanel panel = application.CreateRibbonPanel(TabName, PanelName);
            PushButtonData PushButtonData1 = new PushButtonData("Nested Family","Nested Family", log1, "Ex_Ti_Nested_Family.Command.Cmd");
            PushButton pushbutton1 = panel.AddItem(PushButtonData1) as PushButton;
            pushbutton1.LargeImage = new BitmapImage(new Uri(iconcompletepath1));
            pushbutton1.ToolTip = "Import Line Numbers to Nested Family";

            //string PanelName1 = "Missing Line Number";
            //string addinpath2 = Assembly.GetExecutingAssembly().Location;
            string addinDirPath2 = Path.GetDirectoryName(log2);
            string iconpath2 = @"Resources\MissingLineNumber.ico";
            string iconcompletepath2 = Path.Combine(addinDirPath, iconpath2);
            //application.CreateRibbonTab(TabName);
            //RibbonPanel panel = application.CreateRibbonPanel(TabName, PanelName);
            PushButtonData PushButtonData2 = new PushButtonData("Missing Line Number", "Missing Line Number",log2, "Ex_Ti_Missing_Line_Number.Command.Cmd");
            PushButton pushbutton2 = panel.AddItem(PushButtonData2) as PushButton;
            pushbutton2.LargeImage = new BitmapImage(new Uri(iconcompletepath2));
            pushbutton2.ToolTip = "Find Missing Line Number";

            string log3 = @"C:\Users\vmaruthappan\Desktop\Elbow 45\Elbow 45\PipeSorting\PipeSorting\bin\Debug\PipeSorting.dll";
            string addinDirPath3 = Path.GetDirectoryName(log3);
            string iconpath3 = @"Resources\Elbow.ico";
            string iconcompletepath3 = Path.Combine(addinDirPath, iconpath3);
            //application.CreateRibbonTab(TabName);
            //RibbonPanel panel = application.CreateRibbonPanel(TabName, PanelName);
            PushButtonData PushButtonData3 = new PushButtonData("Elbow", "QA-QC Angle Check", log3, "PipeSorting.RevitMain");
            PushButton pushbutton3 = panel.AddItem(PushButtonData3) as PushButton;
            pushbutton3.LargeImage = new BitmapImage(new Uri(iconcompletepath3));
            pushbutton3.ToolTip = "Find Elbow Angle";



            return Result.Succeeded;
        }
    }
}

